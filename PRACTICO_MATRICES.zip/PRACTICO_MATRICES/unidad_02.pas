
unit UNIDAD_02;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Grids, StdCtrls;

type

  { TMatriz }

  TMatriz = class
  private
    Fila, Columna: Integer;
    Datos: array of array of Real;

  public
    constructor Crear(nf, nc: Integer);

    procedure Cargar(Grilla: TStringGrid);
    procedure Mostrar(Resultado: TMemo);
    procedure Busqueda(valor: Real; Resultado: TMemo);
    procedure Ordenamiento(Grilla: TStringGrid);
    procedure Sumar(B: TMatriz; Resultado: TMemo);
    procedure Restar(B: TMatriz; Resultado: TMemo);
    procedure Multiplicar(B: TMatriz; Resultado: TMemo);
    procedure Invertir(Grilla: TStringGrid; Resultado: TMemo);
    function EsTriangularSuperior: Boolean;
    function EsTriangularInferior: Boolean;
    function Determinante: Real;
    procedure Transpuesta(Grilla: TStringGrid; Resultado: TMemo);
    procedure Inversa(Grilla: TStringGrid; Resultado: TMemo);
    procedure DiagonalPrincipal(Resultado: TMemo);
    procedure DiagonalSecundaria(Resultado: TMemo);
  end;

implementation

constructor TMatriz.Crear(nf, nc: Integer);
begin
  Fila := nf;
  Columna := nc;

  SetLength(Datos, Fila, Columna);
end;

// CARGAR MATRIZ
procedure TMatriz.Cargar(Grilla: TStringGrid);
var
  i, j: Integer;
begin
  for i := 0 to Fila - 1 do
    for j := 0 to Columna - 1 do
    begin
      if not TryStrToFloat(Grilla.Cells[j,i], Datos[i][j]) then
        raise Exception.Create('Ingrese valores numericos en toda la matriz');
    end;
end;

// MOSTRAR MATRIZ
procedure TMatriz.Mostrar(Resultado: TMemo);
var
  i, j: Integer;
  linea: String;
begin
  Resultado.Clear;

  for i := 0 to Fila - 1 do
  begin
    linea := '';

    for j := 0 to Columna - 1 do
      linea := linea + FloatToStr(Datos[i][j]) + '   ';

    Resultado.Lines.Add(linea);
  end;
end;

// BUSQUEDA
procedure TMatriz.Busqueda(valor: Real; Resultado: TMemo);
var
  i, j: Integer;
  encontrado: Boolean;
begin
  encontrado := False;
  Resultado.Clear;

  for i := 0 to Fila - 1 do
    for j := 0 to Columna - 1 do
      if Datos[i][j] = valor then
      begin
        Resultado.Lines.Add('Encontrado en fila ' +
          IntToStr(i+1) + ' columna ' + IntToStr(j+1));

        encontrado := True;
      end;

  if not encontrado then
    Resultado.Lines.Add('Elemento no encontrado');
end;

// ORDENAMIENTO
procedure TMatriz.Ordenamiento(Grilla: TStringGrid);
var
  V: array of Real;
  i, j, k: Integer;
  aux: Real;
begin
  SetLength(V, Fila * Columna);

  k := 0;

  for i := 0 to Fila - 1 do
    for j := 0 to Columna - 1 do
    begin
      V[k] := Datos[i][j];
      k := k + 1;
    end;

  for i := 0 to High(V) - 1 do
    for j := i + 1 to High(V) do
      if V[i] > V[j] then
      begin
        aux := V[i];
        V[i] := V[j];
        V[j] := aux;
      end;

  k := 0;

  for i := 0 to Fila - 1 do
    for j := 0 to Columna - 1 do
    begin
      Datos[i][j] := V[k];
      Grilla.Cells[j,i] := FloatToStr(V[k]);
      k := k + 1;
    end;
end;

function TMatriz.EsTriangularSuperior: Boolean;
var
  i, j: Integer;
begin
  Result := True;

  for i := 1 to Fila - 1 do
    for j := 0 to i - 1 do
      if Datos[i][j] <> 0 then
        Result := False;
end;

function TMatriz.EsTriangularInferior: Boolean;
var
  i, j: Integer;
begin
  Result := True;

  for i := 0 to Fila - 1 do
    for j := i + 1 to Columna - 1 do
      if Datos[i][j] <> 0 then
        Result := False;
end;

procedure TMatriz.DiagonalPrincipal(Resultado: TMemo);
var
  i: Integer;
begin
  Resultado.Clear;
  Resultado.Lines.Add('DIAGONAL PRINCIPAL');

  for i := 0 to Fila - 1 do
    Resultado.Lines.Add(FloatToStr(Datos[i][i]));
end;

procedure TMatriz.DiagonalSecundaria(Resultado: TMemo);
var
  i: Integer;
begin
  Resultado.Clear;
  Resultado.Lines.Add('DIAGONAL SECUNDARIA');

  for i := 0 to Fila - 1 do
    Resultado.Lines.Add(FloatToStr(Datos[i][Columna - 1 - i]));
end;


// SUMAR MATRICES
procedure TMatriz.Sumar(B: TMatriz; Resultado: TMemo);
var
  i, j: Integer;
  linea: String;
begin
  if (Fila <> B.Fila) or (Columna <> B.Columna) then
    raise Exception.Create('Las matrices deben tener las mismas dimensiones');

  Resultado.Clear;
  Resultado.Lines.Add('SUMA DE MATRICES');

  for i := 0 to Fila - 1 do
  begin
    linea := '';

    for j := 0 to Columna - 1 do
      linea := linea + FloatToStr(Datos[i][j] + B.Datos[i][j]) + '   ';

    Resultado.Lines.Add(linea);
  end;
end;

// RESTAR MATRICES
procedure TMatriz.Restar(B: TMatriz; Resultado: TMemo);
var
  i, j: Integer;
  linea: String;
begin
  if (Fila <> B.Fila) or (Columna <> B.Columna) then
    raise Exception.Create('Las matrices deben tener las mismas dimensiones');

  Resultado.Clear;
  Resultado.Lines.Add('RESTA DE MATRICES');

  for i := 0 to Fila - 1 do
  begin
    linea := '';

    for j := 0 to Columna - 1 do
      linea := linea + FloatToStr(Datos[i][j] - B.Datos[i][j]) + '   ';

    Resultado.Lines.Add(linea);
  end;
end;

// MULTIPLICAR MATRICES
procedure TMatriz.Multiplicar(B: TMatriz; Resultado: TMemo);
var
  i, j, k: Integer;
  suma: Real;
  linea: String;
begin
  if Columna <> B.Fila then
    raise Exception.Create('Las columnas de A deben coincidir con las filas de B');

  Resultado.Clear;
  Resultado.Lines.Add('MULTIPLICACION DE MATRICES');

  for i := 0 to Fila - 1 do
  begin
    linea := '';

    for j := 0 to B.Columna - 1 do
    begin
      suma := 0;

      for k := 0 to Columna - 1 do
        suma := suma + Datos[i][k] * B.Datos[k][j];

      linea := linea + FloatToStr(suma) + '   ';
    end;

    Resultado.Lines.Add(linea);
  end;
end;


procedure TMatriz.Invertir(Grilla: TStringGrid; Resultado: TMemo);
var
  i, j: Integer;
  aux: Real;
  linea: String;
begin
  // Intercambiar las filas
  for i := 0 to (Fila div 2) - 1 do
    for j := 0 to Columna - 1 do
    begin
      aux := Datos[i][j];
      Datos[i][j] := Datos[Fila - 1 - i][j];
      Datos[Fila - 1 - i][j] := aux;
    end;

  // Mostrar resultado en el StringGrid
  for i := 0 to Fila - 1 do
    for j := 0 to Columna - 1 do
      Grilla.Cells[j, i] := FloatToStr(Datos[i][j]);

  // Mostrar resultado en el Memo
  Resultado.Clear;
  Resultado.Lines.Add('MATRIZ INVERTIDA');

  for i := 0 to Fila - 1 do
  begin
    linea := '';

    for j := 0 to Columna - 1 do
      linea := linea + FloatToStr(Datos[i][j]) + '   ';

    Resultado.Lines.Add(linea);
  end;
end;

function TMatriz.Determinante: Real;
var
  A: array of array of Real;
  i, j, k, filaPivote: Integer;
  pivote, factor, aux, signo: Real;
begin
  if Fila <> Columna then
    raise Exception.Create('La matriz debe ser cuadrada');

  SetLength(A, Fila, Columna);

  // Copiar los datos
  for i := 0 to Fila - 1 do
    for j := 0 to Columna - 1 do
      A[i][j] := Datos[i][j];

  Result := 1;
  signo := 1;

  // Eliminacion por filas
  for k := 0 to Fila - 1 do
  begin
    filaPivote := k;

    for i := k + 1 to Fila - 1 do
      if Abs(A[i][k]) > Abs(A[filaPivote][k]) then
        filaPivote := i;

    if Abs(A[filaPivote][k]) < 0.000000001 then
    begin
      Result := 0;
      Exit;
    end;

    // Intercambiar filas si es necesario
    if filaPivote <> k then
    begin
      for j := 0 to Columna - 1 do
      begin
        aux := A[k][j];
        A[k][j] := A[filaPivote][j];
        A[filaPivote][j] := aux;
      end;

      signo := -signo;
    end;

    pivote := A[k][k];

    Result := Result * pivote;

    for i := k + 1 to Fila - 1 do
    begin
      factor := A[i][k] / pivote;

      for j := k + 1 to Columna - 1 do
        A[i][j] := A[i][j] - factor * A[k][j];
    end;
  end;

  Result := Result * signo;
end;


procedure TMatriz.Transpuesta(Grilla: TStringGrid; Resultado: TMemo);
var
  i, j: Integer;
  aux: Real;
  linea: String;
begin
  if Fila <> Columna then
    raise Exception.Create('La matriz debe ser cuadrada');

  // Intercambiar filas por columnas
  for i := 0 to Fila - 1 do
    for j := i + 1 to Columna - 1 do
    begin
      aux := Datos[i][j];
      Datos[i][j] := Datos[j][i];
      Datos[j][i] := aux;
    end;

  // Actualizar el StringGrid
  for i := 0 to Fila - 1 do
    for j := 0 to Columna - 1 do
      Grilla.Cells[j, i] := FloatToStr(Datos[i][j]);

  // Mostrar en el Memo
  Resultado.Clear;
  Resultado.Lines.Add('MATRIZ TRANSPUESTA');

  for i := 0 to Fila - 1 do
  begin
    linea := '';

    for j := 0 to Columna - 1 do
      linea := linea + FloatToStr(Datos[i][j]) + '   ';

    Resultado.Lines.Add(linea);
  end;
end;


procedure TMatriz.Inversa(Grilla: TStringGrid; Resultado: TMemo);
var
  A: array of array of Real;
  i, j, k, filaPivote: Integer;
  pivote, factor, aux: Real;
  linea: String;
begin
  if Fila <> Columna then
    raise Exception.Create('La matriz debe ser cuadrada');

  SetLength(A, Fila, Columna * 2);

  // Crear la matriz aumentada [A | I]
  for i := 0 to Fila - 1 do
    for j := 0 to Columna * 2 - 1 do
    begin
      if j < Columna then
        A[i][j] := Datos[i][j]
      else
      if j - Columna = i then
        A[i][j] := 1
      else
        A[i][j] := 0;
    end;

  // Metodo de Gauss-Jordan
  for k := 0 to Fila - 1 do
  begin
    filaPivote := k;

    for i := k + 1 to Fila - 1 do
      if Abs(A[i][k]) > Abs(A[filaPivote][k]) then
        filaPivote := i;

    if Abs(A[filaPivote][k]) < 0.000000001 then
      raise Exception.Create('La matriz no tiene inversa');

    // Intercambiar filas
    if filaPivote <> k then
      for j := 0 to Columna * 2 - 1 do
      begin
        aux := A[k][j];
        A[k][j] := A[filaPivote][j];
        A[filaPivote][j] := aux;
      end;

    // Convertir el pivote en 1
    pivote := A[k][k];

    for j := 0 to Columna * 2 - 1 do
      A[k][j] := A[k][j] / pivote;

    // Hacer ceros en las demas filas
    for i := 0 to Fila - 1 do
      if i <> k then
      begin
        factor := A[i][k];

        for j := 0 to Columna * 2 - 1 do
          A[i][j] := A[i][j] - factor * A[k][j];
      end;
  end;

  // Guardar la inversa en Datos
  for i := 0 to Fila - 1 do
    for j := 0 to Columna - 1 do
      Datos[i][j] := A[i][j + Columna];

  // Actualizar el StringGrid
  for i := 0 to Fila - 1 do
    for j := 0 to Columna - 1 do
      Grilla.Cells[j, i] := FloatToStr(Datos[i][j]);

  // Mostrar en el Memo
  Resultado.Clear;
  Resultado.Lines.Add('MATRIZ INVERSA');

  for i := 0 to Fila - 1 do
  begin
    linea := '';

    for j := 0 to Columna - 1 do
      linea := linea + FloatToStr(Datos[i][j]) + '   ';

    Resultado.Lines.Add(linea);
  end;
end;

end.

