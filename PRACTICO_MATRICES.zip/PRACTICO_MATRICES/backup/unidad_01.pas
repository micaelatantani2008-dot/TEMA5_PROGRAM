
unit UNIDAD_01;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics,
  Dialogs, StdCtrls, Grids, UNIDAD_02;

type

  { TForm1 }

  TForm1 = class(TForm)
    Btn: TButton;
    BtnOrdenar: TButton;
    BtnCargar: TButton;
    BtnMostrar: TButton;
    BtnBuscar: TButton;
    BtnInversa: TButton;
    BtnDiagonalP: TButton;
    BtnDiagonalS: TButton;
    BtnSumar: TButton;
    BtnRestar: TButton;
    BtnMultiplicar: TButton;
    BtnInvertir: TButton;
    BtnDeterminante: TButton;
    BtnTranspuesta: TButton;
    BtnTriangular: TButton;
    EditFila: TEdit;
    EditColumna: TEdit;
    Label1: TLabel;
    MemoResultado: TMemo;
    SG_Matriz: TStringGrid;
    SG_Matriz2: TStringGrid;

    procedure BtnCargarClick(Sender: TObject);
    procedure BtnMostrarClick(Sender: TObject);
    procedure BtnBuscarClick(Sender: TObject);
    procedure BtnOrdenarClick(Sender: TObject);

    procedure BtnTriangularClick(Sender: TObject);
    procedure BtnDiagonalPClick(Sender: TObject);
    procedure BtnDiagonalSClick(Sender: TObject);
    procedure BtnSumarClick(Sender: TObject);
    procedure BtnRestarClick(Sender: TObject);
    procedure BtnMultiplicarClick(Sender: TObject);
    procedure BtnInvertirClick(Sender: TObject);
    procedure BtnDeterminanteClick(Sender: TObject);
    procedure BtnTranspuestaClick(Sender: TObject);
    procedure BtnInversaClick(Sender: TObject);

  private
    Matriz: TMatriz;
    Matriz2: TMatriz;
    EsCuadrada: Boolean;
    procedure ControlarBotones;

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ CONTROLAR BOTONES }

procedure TForm1.ControlarBotones;
begin
  BtnTriangular.Enabled := EsCuadrada;
  BtnDiagonalP.Enabled := EsCuadrada;
  BtnDiagonalS.Enabled := EsCuadrada;
  BtnSumar.Enabled := EsCuadrada;
  BtnRestar.Enabled := EsCuadrada;
  BtnMultiplicar.Enabled := EsCuadrada;
  BtnInvertir.Enabled := EsCuadrada;
  BtnDeterminante.Enabled := EsCuadrada;
  BtnTranspuesta.Enabled := EsCuadrada;
  BtnInversa.Enabled := EsCuadrada;
end;

{ CREAR MATRIZ }

procedure TForm1.BtnCargarClick(Sender: TObject);
var
  nf, nc: Integer;
  i, j: Integer;
begin
  nf := StrToIntDef(EditFila.Text, 0);
  nc := StrToIntDef(EditColumna.Text, 0);

  if (nf <= 0) or (nc <= 0) then
  begin
    ShowMessage('Ingrese dimensiones validas');
    Exit;
  end;

  if Assigned(Matriz) then
    FreeAndNil(Matriz);

  if Assigned(Matriz2) then
    FreeAndNil(Matriz2);

  // Crear matriz A
  Matriz := TMatriz.Crear(nf, nc);

  // Crear matriz B
  Matriz2 := TMatriz.Crear(nf, nc);

  // Configurar matriz A
  SG_Matriz.FixedRows := 0;
  SG_Matriz.FixedCols := 0;
  SG_Matriz.RowCount := nf;
  SG_Matriz.ColCount := nc;

  // Configurar matriz B
  SG_Matriz2.FixedRows := 0;
  SG_Matriz2.FixedCols := 0;
  SG_Matriz2.RowCount := nf;
  SG_Matriz2.ColCount := nc;

  EsCuadrada := (nf = nc);

  ControlarBotones;

  // Limpiar ambas matrices
  for i := 0 to nf - 1 do
    for j := 0 to nc - 1 do
    begin
      SG_Matriz.Cells[j, i] := '';
      SG_Matriz2.Cells[j, i] := '';
    end;

  MemoResultado.Clear;

  ShowMessage('Matrices A y B de ' + IntToStr(nf) +
    ' x ' + IntToStr(nc) + ' creadas');
end;


{ MOSTRAR MATRIZ }

procedure TForm1.BtnMostrarClick(Sender: TObject);
begin
  if not Assigned(Matriz) then
  begin
    ShowMessage('Primero cargue la matriz');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);
    Matriz.Mostrar(MemoResultado);
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ BUSCAR ELEMENTO }

procedure TForm1.BtnBuscarClick(Sender: TObject);
var
  valor: Real;
  dato: String;
begin
  if not Assigned(Matriz) then
  begin
    ShowMessage('Primero cargue la matriz');
    Exit;
  end;

  dato := InputBox('BUSQUEDA', 'Ingrese el numero:', '');

  if not TryStrToFloat(dato, valor) then
  begin
    ShowMessage('Ingrese un numero valido');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);
    Matriz.Busqueda(valor, MemoResultado);
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ ORDENAR MATRIZ }

procedure TForm1.BtnOrdenarClick(Sender: TObject);
begin
  if not Assigned(Matriz) then
  begin
    ShowMessage('Primero cargue la matriz');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);
    Matriz.Ordenamiento(SG_Matriz);
    Matriz.Mostrar(MemoResultado);
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ MATRIZ TRIANGULAR }

procedure TForm1.BtnTriangularClick(Sender: TObject);
begin
  if not Assigned(Matriz) then
  begin
    ShowMessage('Primero cargue la matriz');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);

    if Matriz.EsTriangularSuperior then
      ShowMessage('La matriz es triangular superior')
    else
    if Matriz.EsTriangularInferior then
      ShowMessage('La matriz es triangular inferior')
    else
      ShowMessage('La matriz no es triangular');

  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ DIAGONAL PRINCIPAL }

procedure TForm1.BtnDiagonalPClick(Sender: TObject);
begin
  if not Assigned(Matriz) then
  begin
    ShowMessage('Primero cargue la matriz');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);
    Matriz.DiagonalPrincipal(MemoResultado);
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ DIAGONAL SECUNDARIA }

procedure TForm1.BtnDiagonalSClick(Sender: TObject);
begin
  if not Assigned(Matriz) then
  begin
    ShowMessage('Primero cargue la matriz');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);
    Matriz.DiagonalSecundaria(MemoResultado);
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ SUMAR MATRICES }

procedure TForm1.BtnSumarClick(Sender: TObject);
begin
  if (not Assigned(Matriz)) or (not Assigned(Matriz2)) then
  begin
    ShowMessage('Primero cree las matrices');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);
    Matriz2.Cargar(SG_Matriz2);
    Matriz.Sumar(Matriz2, MemoResultado);
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ RESTAR MATRICES }

procedure TForm1.BtnRestarClick(Sender: TObject);
begin
  if (not Assigned(Matriz)) or (not Assigned(Matriz2)) then
  begin
    ShowMessage('Primero cree las matrices');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);
    Matriz2.Cargar(SG_Matriz2);
    Matriz.Restar(Matriz2, MemoResultado);
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ MULTIPLICAR MATRICES }

procedure TForm1.BtnMultiplicarClick(Sender: TObject);
begin
  if (not Assigned(Matriz)) or (not Assigned(Matriz2)) then
  begin
    ShowMessage('Primero cree las matrices');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);
    Matriz2.Cargar(SG_Matriz2);
    Matriz.Multiplicar(Matriz2, MemoResultado);
  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ INVERTIR MATRIZ }


procedure TForm1.BtnInvertirClick(Sender: TObject);
begin
  if not Assigned(Matriz) then
  begin
    ShowMessage('Primero cargue la matriz');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);

    Matriz.Invertir(SG_Matriz, MemoResultado);

  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;


{ DETERMINANTE }

procedure TForm1.BtnDeterminanteClick(Sender: TObject);
var
  resultado: Real;
begin
  if not Assigned(Matriz) then
  begin
    ShowMessage('Primero cargue la matriz');
    Exit;
  end;

  try
    Matriz.Cargar(SG_Matriz);

    resultado := Matriz.Determinante;

    MemoResultado.Clear;
    MemoResultado.Lines.Add('DETERMINANTE');
    MemoResultado.Lines.Add(FloatToStr(resultado));

  except
    on E: Exception do
      ShowMessage(E.Message);
  end;
end;

{ TRANSPUESTA }

procedure TForm1.BtnTranspuestaClick(Sender: TObject);
begin
  ShowMessage('Transpuesta pendiente de implementar');
end;

{ MATRIZ INVERSA }

procedure TForm1.BtnInversaClick(Sender: TObject);
begin
  ShowMessage('Matriz inversa pendiente de implementar');
end;

end.

